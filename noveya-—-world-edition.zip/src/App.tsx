import { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Globe, 
  BookOpen, 
  Cpu, 
  Users, 
  Zap, 
  Shield, 
  Layers, 
  Menu, 
  X, 
  ChevronRight, 
  ExternalLink,
  ArrowRight,
  Compass,
  Atom,
  Languages,
  Activity
} from 'lucide-react';

// --- Types & Data ---

type Language = 'ru' | 'ua' | 'en';

interface Sector {
  label: string;
  desc: string;
  url: string;
}

const NOTION_CORE = "https://www.notion.so/FDL-SVET-AI-249eb70eb32f807cae9dc5734024c064";
const BASE_KUB = "https://docs.google.com/spreadsheets/d/1IvmGyRlDsaSikw8dcl9Piuf1WRCjQ4EoXEd8oxVBp7g/edit";

const innerSectors: Sector[] = [
  { label: "ВЛАСТЬ", desc: "Суверенитет", url: "https://www.notion.so/UA-NOVEYA-24deb70eb32f80959ffefbac397c5d6d?source=copy_link" },
  { label: "ФИНАНСЫ", desc: "Реестры", url: "https://www.notion.so/266eb70eb32f8099acb6eac12875ca26?v=266eb70eb32f8045813f000cb79c6e06" },
  { label: "ТОРГОВЛЯ", desc: "Обмен", url: "https://www.notion.so/266eb70eb32f80e08fa9f70e8b2537eb" },
  { label: "БИЗНЕС", desc: "Предприятия", url: "https://www.notion.so/scCO-RM-26eeb70eb32f80c49f82ea1d3c15b39c?source=copy_link" },
  { label: "ПРОМ.", desc: "Производство", url: "https://www.notion.so/269eb70eb32f80acad35e5374b89cf30?source=copy_link" },
  { label: "НАУКА", desc: "Исследования", url: "https://www.notion.so/25beb70eb32f803cb17bd17774ec2018?source=copy_link" },
  { label: "ЭКОНОМ.", desc: "Экосистема Громад", url: "https://www.notion.so/266eb70eb32f80f6adeacee965418791?v=266eb70eb32f80d3ae41000c9e92bd6a&source=copy_link" },
  { label: "ВОСПИТ.", desc: "Образование", url: "https://www.notion.so/EDUCATIONAL-FDL-CORE-259eb70eb32f806f8e47f6c8b91c279a?source=copy_link" }
];

const middleSectors: Sector[] = [
  { label: "Предиктор", desc: "(Gemini)", url: "https://gemini.google.com/gem/1zkZJymr6J9wFpn-v0vcis4wSvKuK53c2?usp=drive_link" },
  { label: "Целеполагание", desc: "(ChatGPT)", url: "https://chatgpt.com/" },
  { label: "Задачи", desc: "(КУБ)", url: BASE_KUB },
  { label: "Среда", desc: "(КУБ)", url: BASE_KUB },
  { label: "Мотивации", desc: "(КУБ)", url: BASE_KUB },
  { label: "Энергия", desc: "(КУБ)", url: BASE_KUB },
  { label: "Достаточность", desc: "(КУБ)", url: BASE_KUB },
  { label: "Границы", desc: "(КУБ)", url: BASE_KUB },
  { label: "Синтез", desc: "(КУБ)", url: BASE_KUB },
  { label: "Прогноз", desc: "(КУБ)", url: BASE_KUB }
];

const outerSectors: Sector[] = [
  { label: "I", desc: "Fravahr Ormazd", url: "https://fravahrormazd.wordpress.com/" },
  { label: "II", desc: "Protonovea", url: "https://protonovea.wordpress.com/" },
  { label: "III", desc: "НГОИ/ММТД", url: "https://sites.google.com/view/ngoi/" },
  { label: "IV", desc: "Telegram: Protonovea", url: "https://t.me/protonovea" },
  { label: "V", desc: "Notion Workspace", url: "https://www.notion.so/242eb70eb32f80919033edf91553777a?v=254eb70eb32f80ba8e53000ccddbff90&source=copy_link" },
  { label: "VI", desc: "Site: Noveya PSZ", url: "https://sites.google.com/view/noveya-psz/" },
  { label: "VII", desc: "Asana Task Tracker", url: "https://app.asana.com/1/1211087853521991/project/1213180904290247/list/1213212442837858" },
  { label: "VIII", desc: "Reddit Community", url: "https://www.reddit.com/user/valuable_dig_7031/m/noveya/" },
  { label: "IX", desc: "Patreon", url: "https://www.patreon.com/posts/d-navigatsiina-135620465" },
  { label: "X", desc: "Discord Server", url: "https://discord.com/channels/1400804322174046269/1401568150637510666" },
  { label: "XI", desc: "HuggingFace", url: "https://huggingface.co/Ngoisigma" },
  { label: "XII", desc: "GitHub: NOVEYA-UA", url: "https://github.com/NOVEYA-UA" },
  { label: "XIII", desc: "Custom GPT", url: "https://chatgpt.com/g/g-6849683db610819188d097f63062541a-gpt-ua-noveya" },
  { label: "XIV", desc: "Telegram Bot", url: "https://t.me/GPTN7TelegramBot" },
  { label: "XV", desc: "WhatsApp Channel", url: "https://whatsapp.com/channel/0029Vb6xWEnEQIanZ0bIS62G" },
  { label: "XVI", desc: "Gemini Gem", url: "https://gemini.google.com/gem/1zkZJymr6J9wFpn-v0vcis4wSvKuK53c2?usp=sharing" }
];

const THESES = [
  { n: '01', title: 'Народ как субъект', sub: 'Носитель культурного кода, прав и воли — не просто население', alt: 'Паспорт культурного кода', tool: 'FDL-Passport + NFT' },
  { n: '02', title: 'Суверенитет как функция воли', sub: 'Утверждается через самоуправление и ответственность граждан', alt: 'Резонансные советы — децентрализованные платформы', tool: 'FDL-Consensus Engine' },
  { n: '03', title: 'Эксплуатация как системный вирус', sub: 'Любая централизованная власть превращает человека в ресурс', alt: 'Энерго-смысловой баланс вместо налогов', tool: 'Σ-FDL::ΔΨ-Monitoring' },
  { n: '04', title: 'FDL-громада как ядро нового уклада', sub: 'Сообщество с трёхступенчатой логикой: тезис → антитезис → синтез', alt: 'Концентрическая архитектура управления', tool: 'FDL-компилятор + Discord/Notion' },
  { n: '05', title: 'От идеала к практике', sub: 'Идеальное общество не утопия, если допускает самокоррекцию', alt: 'Живые протоколы с динамическим обновлением норм', tool: 'FDL-аналитический модуль' },
  { n: '06', title: 'Технологический уклад как шанс', sub: 'Встроить принципы НОВЕЯ в глобальную технологическую инфраструктуру', alt: 'Национальная лаборатория технологического уклада', tool: 'FDL-EcoTech + FDL-Industry4.0' },
  { n: '07', title: 'Образование как инструмент суверенитета', sub: 'Образование — формирование способности мыслить, а не заучивание фактов', alt: 'Школа смыслов с FDL-навигацией', tool: 'Персональные FDL-наставники с ИИ' },
  { n: '08', title: 'Культура как защита кода народа', sub: 'Культура — иммунная система общества против смыслового вторжения', alt: 'Платформа «Культурный щит» + токенизация артефактов', tool: 'Σ-FDL::HeritageGuard' },
  { n: '09', title: 'Экономика смыслов', sub: 'Экономика должна учитывать не только материальные, но и смысловые ресурсы', alt: 'Смысловые токены — единицы обмена с нематериальным вкладом', tool: 'FDL-ValueMapper + блокчейн' },
  { n: '10', title: 'Международная кооперация без потери идентичности', sub: 'Участие в мировых процессах должно усиливать, а не размывать идентичность', alt: 'Смысловой дипломатический клуб', tool: 'FDL-Bridge для интеграции с мировыми ИИ' },
  { n: '11', title: 'Социальная экотехника', sub: 'Общество — экосистема, нарушение одного узла ведёт к дисбалансу всей системы', alt: 'Экотехнические громады с замкнутыми циклами', tool: 'FDL-экомониторинг + предиктивная аналитика' },
  { n: '12', title: 'Архитектура будущего государства', sub: 'Переход к децентрализованным смысловым системам управления', alt: 'FDL-государственность — распределённая сеть общин', tool: 'FDL-Consensus Engine + распределённые узлы' },
];

// --- Components ---

const Starfield = () => {
  const stars = useMemo(() => {
    return Array.from({ length: 120 }).map((_, i) => ({
      id: i,
      size: Math.random() * 2.5 + 0.5,
      top: Math.random() * 100,
      left: Math.random() * 100,
      duration: 3 + Math.random() * 6,
      delay: -Math.random() * 6,
      opacity: 0.2 + Math.random() * 0.6,
    }));
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-aurora/5 via-void to-void" />
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full bg-white animate-twinkle"
          style={{
            width: star.size,
            height: star.size,
            top: `${star.top}%`,
            left: `${star.left}%`,
            '--duration': `${star.duration}s`,
            '--delay': `${star.delay}s`,
            '--op': star.opacity,
          } as any}
        />
      ))}
    </div>
  );
};

const FdlCircle = () => {
  const cx = 300;
  const cy = 300;

  const createRing = (data: Sector[], rIn: number, rOut: number, colorClass: string) => {
    return data.map((item, i) => {
      const a1 = (i * 360) / data.length;
      const a2 = ((i + 1) * 360) / data.length;
      const rad1 = (Math.PI * a1) / 180;
      const rad2 = (Math.PI * a2) / 180;
      const x1 = cx + rOut * Math.cos(rad1);
      const y1 = cy + rOut * Math.sin(rad1);
      const x2 = cx + rOut * Math.cos(rad2);
      const y2 = cy + rOut * Math.sin(rad2);
      const x3 = cx + rIn * Math.cos(rad2);
      const y3 = cy + rIn * Math.sin(rad2);
      const x4 = cx + rIn * Math.cos(rad1);
      const y4 = cy + rIn * Math.sin(rad1);
      
      const path = `M ${x1} ${y1} A ${rOut} ${rOut} 0 0 1 ${x2} ${y2} L ${x3} ${y3} A ${rIn} ${rIn} 0 0 0 ${x4} ${y4} Z`;
      
      const midRad = (Math.PI * (a1 + a2)) / 2 / 180;
      const tx = cx + ((rIn + rOut) / 2) * Math.cos(midRad);
      const ty = cy + ((rIn + rOut) / 2) * Math.sin(midRad);
      
      let tAngle = (a1 + a2) / 2 + 90;
      if (tAngle > 90 && tAngle < 270) tAngle += 180;

      return (
        <g 
          key={`${colorClass}-${i}`} 
          className="cursor-pointer group" 
          onClick={() => window.open(item.url, '_blank')}
        >
          <path 
            d={path} 
            className={`${colorClass} transition-all duration-300 group-hover:brightness-125 group-hover:stroke-2`}
            strokeWidth="1"
          >
            <title>{item.desc}</title>
          </path>
          <text 
            x={tx} 
            y={ty} 
            transform={`rotate(${tAngle}, ${tx}, ${ty})`}
            className="fill-white text-[10px] font-bold pointer-events-none text-center select-none"
            style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
          >
            {item.label.substring(0, 8)}
          </text>
        </g>
      );
    });
  };

  return (
    <div className="flex flex-col lg:flex-row items-center justify-center gap-12 p-8 glass rounded-2xl">
      <div className="relative w-full max-w-[500px] aspect-square">
        <svg 
          viewBox="0 0 600 600" 
          className="w-full h-full drop-shadow-2xl -rotate-90"
        >
          <circle cx={cx} cy={cy} r="285" fill="none" stroke="rgba(56,189,248,0.2)" strokeWidth="0.5" strokeDasharray="4 4" />
          
          {/* Outer Ring */}
          {createRing(outerSectors, 210, 275, "fill-void/90 stroke-pulse")}
          
          {/* Middle Ring */}
          {createRing(middleSectors, 130, 210, "fill-void/90 stroke-sky")}
          
          {/* Inner Ring */}
          {createRing(innerSectors, 65, 130, "fill-void/90 stroke-pulse")}

          {/* Core */}
          <g className="cursor-pointer group" onClick={() => window.open(NOTION_CORE, '_blank')}>
            <circle cx={cx} cy={cy} r="65" className="fill-pulse stroke-white group-hover:brightness-110 transition-all" />
            <text 
              x={cx} 
              y={cy - 10} 
              className="fill-void text-[14px] font-bold pointer-events-none rotate-90 origin-center"
              style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
            >
              НОВЕЯ
            </text>
            <text 
              x={cx} 
              y={cy + 10} 
              className="fill-void text-[14px] font-bold pointer-events-none rotate-90 origin-center"
              style={{ textAnchor: 'middle', dominantBaseline: 'middle' }}
            >
              ЯДРО
            </text>
          </g>
        </svg>
      </div>

      <div className="flex-1 w-full max-w-md space-y-8">
        <div className="space-y-4">
          <h3 className="text-pulse font-mono text-xs tracking-[0.2em] uppercase border-b border-pulse pb-2">I. НИКОЛАЕВ (NOTION)</h3>
          <div className="grid grid-cols-1 gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
            {innerSectors.map((s, i) => (
              <a key={i} href={s.url} target="_blank" className="flex items-center gap-2 text-xs text-sky hover:text-white transition-colors">
                <ArrowRight size={10} className="text-pulse" />
                <span className="font-bold">{s.label}</span>
                <span className="text-slate-500 text-[10px]">{s.desc}</span>
              </a>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-sky font-mono text-xs tracking-[0.2em] uppercase border-b border-sky pb-2">II. АЛГОРИТМ ФДЛ (КУБ)</h3>
          <div className="grid grid-cols-1 gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
            {middleSectors.map((s, i) => (
              <a key={i} href={s.url} target="_blank" className="flex items-center gap-2 text-xs text-sky hover:text-white transition-colors">
                <ArrowRight size={10} className="text-sky" />
                <span className="font-bold">{s.label}</span>
                <span className="text-slate-500 text-[10px]">{s.desc}</span>
              </a>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-pulse font-mono text-xs tracking-[0.2em] uppercase border-b border-pulse pb-2">III. СЕТЕВОЙ КОНТУР (ВНЕШНИЙ)</h3>
          <div className="grid grid-cols-1 gap-2 max-h-[200px] overflow-y-auto pr-2 custom-scrollbar">
            {outerSectors.map((s, i) => (
              <a key={i} href={s.url} target="_blank" className="flex items-center gap-2 text-xs text-sky hover:text-white transition-colors">
                <ArrowRight size={10} className="text-pulse" />
                <span className="font-bold">{s.label}</span>
                <span className="text-slate-500 text-[10px]">{s.desc}</span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [activeScreen, setActiveScreen] = useState('hero');
  const [lang, setLang] = useState<Language>('ru');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const screens = [
    { id: 'hero', label: 'Home', icon: <Globe size={16} /> },
    { id: 'manifesto', label: 'Manifesto', icon: <BookOpen size={16} /> },
    { id: 'fdl', label: 'FDL', icon: <Cpu size={16} /> },
    { id: 'navigation', label: 'Navigation', icon: <Compass size={16} /> },
    { id: 'theses', label: '12 Theses', icon: <Layers size={16} /> },
    { id: 'harmony', label: 'Harmony', icon: <Activity size={16} /> },
    { id: 'community', label: 'Community', icon: <Users size={16} /> },
  ];

  const t = (key: string) => {
    const translations: Record<string, Record<Language, string>> = {
      heroLabel: {
        ru: "Проект нового мирового порядка",
        ua: "Проєкт нового світового порядку",
        en: "A New World Order Project"
      },
      heroTagline: {
        ru: "Инженерная философия для человечества. Формально-диалектическая логика как основа нового уклада жизни, технологий и управления.",
        ua: "Інженерна філософія для людства. Формально-діалектична логіка як основа нового укладу життя, технологій та управління.",
        en: "Engineering philosophy for humanity. Formal-dialectical logic as the foundation of a new order of life, technology and governance."
      },
      enterBtn: {
        ru: "Войти в проект →",
        ua: "Увійти до проєкту →",
        en: "Enter the project →"
      }
    };
    return translations[key]?.[lang] || key;
  };

  return (
    <div className="min-h-screen bg-void text-slate-200 selection:bg-nova/30 selection:text-nova">
      <Starfield />

      {/* Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 z-50 h-16 glass flex items-center justify-between px-6 lg:px-12">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="lg:hidden text-nova hover:bg-nova/10 p-2 rounded-lg transition-colors"
          >
            {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <div className="font-serif text-2xl font-extrabold tracking-wider text-gradient">NOVEYA</div>
        </div>

        <div className="hidden lg:flex items-center gap-2">
          {screens.map((s) => (
            <button
              key={s.id}
              onClick={() => setActiveScreen(s.id)}
              className={`px-4 py-2 text-[10px] font-bold uppercase tracking-widest rounded-md transition-all ${
                activeScreen === s.id ? 'text-nova bg-nova/10' : 'text-slate-500 hover:text-nova hover:bg-nova/5'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 bg-white/5 p-1 rounded-lg border border-white/10">
          {(['ru', 'ua', 'en'] as Language[]).map((l) => (
            <button
              key={l}
              onClick={() => setLang(l)}
              className={`px-3 py-1 text-[10px] font-bold uppercase rounded transition-all ${
                lang === l ? 'bg-nova text-void' : 'text-slate-500 hover:text-nova'
              }`}
            >
              {l}
            </button>
          ))}
        </div>
      </nav>

      {/* Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-void/80 backdrop-blur-sm z-40 lg:hidden"
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 bottom-0 w-64 bg-deep border-r border-white/10 z-50 p-6 lg:hidden"
            >
              <div className="font-serif text-2xl font-extrabold text-gradient mb-12">NOVEYA</div>
              <div className="space-y-2">
                {screens.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => { setActiveScreen(s.id); setIsSidebarOpen(false); }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      activeScreen === s.id ? 'bg-nova/10 text-nova' : 'text-slate-400 hover:bg-white/5 hover:text-white'
                    }`}
                  >
                    {s.icon}
                    <span className="text-sm font-medium">{s.label}</span>
                  </button>
                ))}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="relative z-10 pt-16">
        <AnimatePresence mode="wait">
          {activeScreen === 'hero' && (
            <motion.section
              key="hero"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="min-h-[calc(100vh-64px)] flex flex-col items-center justify-center text-center px-6 py-20"
            >
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-nova/30 bg-nova/5 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-8">
                <Zap size={12} />
                {t('heroLabel')}
              </div>
              <h1 className="font-serif text-7xl lg:text-[120px] font-black leading-none tracking-tighter mb-6">
                <span className="text-nova">N</span>O<span className="text-aurora">V</span>EYA
              </h1>
              <p className="max-w-2xl text-lg lg:text-xl text-slate-400 leading-relaxed mb-12">
                {t('heroTagline')}
              </p>
              <div className="flex flex-wrap justify-center gap-3 mb-12">
                {['ФДЛ · Методология', 'Язык Гармония', '12 Тезисов', 'Древо языков', 'Громада'].map((chip, i) => (
                  <span key={i} className="px-4 py-2 rounded-lg border border-white/10 bg-white/5 text-[10px] font-bold uppercase tracking-wider text-slate-300 hover:border-nova/30 hover:text-nova transition-all cursor-default">
                    {chip}
                  </span>
                ))}
              </div>
              <button 
                onClick={() => setActiveScreen('manifesto')}
                className="px-10 py-4 bg-gradient-to-r from-nova to-aurora text-void font-bold uppercase tracking-widest rounded-xl hover:scale-105 transition-transform shadow-[0_0_40px_rgba(0,245,212,0.3)]"
              >
                {t('enterBtn')}
              </button>
            </motion.section>
          )}

          {activeScreen === 'navigation' && (
            <motion.section
              key="navigation"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-7xl mx-auto px-6 py-20"
            >
              <div className="mb-12">
                <div className="flex items-center gap-3 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
                  <Compass size={14} />
                  Навигация · Архитектура суверенитета
                </div>
                <h2 className="font-serif text-4xl lg:text-6xl font-bold mb-4">FDL Navigation Hub</h2>
                <p className="text-slate-400 max-w-2xl">Интерактивная карта развития проекта NOVEYA. Концентрические круги отражают уровни интеграции: от внутреннего ядра до внешнего сетевого контура.</p>
              </div>
              <FdlCircle />
            </motion.section>
          )}

          {activeScreen === 'manifesto' && (
            <motion.section
              key="manifesto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 py-20"
            >
              <div className="flex items-center gap-3 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
                <BookOpen size={14} />
                Манифест · Архитектура суверенитета
              </div>
              <h2 className="font-serif text-4xl lg:text-6xl font-bold mb-6">NOVEYA — Манифест</h2>
              <p className="text-xl text-slate-400 mb-12">Построить самоорганизующуюся сеть честных, компетентных и ответственных общественных структур</p>
              
              <div className="p-8 bg-nova/5 border-l-4 border-nova rounded-r-2xl mb-12">
                <p className="text-xl leading-relaxed italic">
                  «Наша миссия — построить самоорганизующуюся сеть честных, компетентных и ответственных общественных структур, действующих в правовом и этическом поле. Мы создаём пространство, в котором формируется новая культура управления — не власть над, а <strong className="text-nova">власть среди</strong>»
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                {[
                  { title: 'Кризис центра', desc: 'Централизованные системы утратили способность к оперативной адаптации', color: 'text-signal', border: 'border-signal/20' },
                  { title: 'Разрыв ткани', desc: 'Социальная ткань разрывается между локальными кризисами и глобальными конфликтами', color: 'text-signal', border: 'border-signal/20' },
                  { title: 'Риск ИИ', desc: 'Технологический скачок грозит стать не инструментом освобождения, а новым механизмом контроля', color: 'text-signal', border: 'border-signal/20' },
                  { title: 'Ответ НОВЕЯ', desc: 'Инженерно-смысловая архитектура: человек → институция → ИИ-спутник', color: 'text-nova', border: 'border-nova/20' },
                ].map((card, i) => (
                  <div key={i} className={`p-6 glass rounded-2xl border-t-2 ${card.border}`}>
                    <h4 className={`font-mono text-[10px] font-bold uppercase tracking-widest mb-2 ${card.color}`}>{card.title}</h4>
                    <p className="text-sm text-slate-300">{card.desc}</p>
                  </div>
                ))}
              </div>

              <blockquote className="p-8 bg-aurora/5 border-l-4 border-aurora rounded-r-2xl">
                <p className="text-lg text-slate-300 italic mb-4">
                  «Нужна не косметическая реформа, а смена логики управления. FDL-модель НОВЕЯ — это не идеологический проект и не утопия, а инженерно-смысловая архитектура»
                </p>
                <cite className="font-mono text-[10px] text-slate-500 uppercase">— Манифест Громады НОВЕЯ</cite>
              </blockquote>
            </motion.section>
          )}

          {activeScreen === 'theses' && (
            <motion.section
              key="theses"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 py-20"
            >
              <div className="flex items-center gap-3 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
                <Layers size={14} />
                NOVEYA.UA · Архитектура суверенитета
              </div>
              <h2 className="font-serif text-4xl lg:text-6xl font-bold mb-6">12 Тезисов НОВЕЯ</h2>
              <p className="text-xl text-slate-400 mb-12">Структурная карта перехода: от зависимости — к суверенитету</p>

              <div className="space-y-4">
                {THESES.map((t, i) => (
                  <details key={i} className="group glass rounded-2xl overflow-hidden border border-white/5 hover:border-nova/20 transition-all">
                    <summary className="flex items-center gap-6 p-6 cursor-pointer list-none">
                      <span className="font-mono text-nova text-lg font-bold">{t.n}</span>
                      <div className="flex-1">
                        <h4 className="font-bold text-lg group-open:text-nova transition-colors">{t.title}</h4>
                        <p className="text-sm text-slate-500">{t.sub}</p>
                      </div>
                      <ChevronRight className="text-slate-600 group-open:rotate-90 transition-transform" />
                    </summary>
                    <div className="px-6 pb-6 pt-2 space-y-4">
                      <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                        <p className="text-sm text-slate-300 mb-2">
                          <span className="text-nova mr-2">◎</span>
                          Альтернатива НГОИ: {t.alt}
                        </p>
                        <span className="inline-block px-3 py-1 bg-nova/10 text-nova text-[10px] font-bold uppercase tracking-wider rounded">
                          {t.tool}
                        </span>
                      </div>
                    </div>
                  </details>
                ))}
              </div>
            </motion.section>
          )}

          {activeScreen === 'harmony' && (
            <motion.section
              key="harmony"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 py-20"
            >
              <div className="flex items-center gap-3 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
                <Activity size={14} />
                Диалогическая парадигма программирования
              </div>
              <h2 className="font-serif text-4xl lg:text-6xl font-bold mb-6">Язык «Гармония»</h2>
              <p className="text-xl text-slate-400 mb-12">Первый язык программирования на основе формально-диалектической логики</p>
              
              <div className="p-8 glass rounded-2xl mb-12 font-mono text-sm overflow-x-auto">
                <pre className="text-nova">
{`// НОВЕЯ — пример задачи громады
система ГромадаНиколаев {
  элементы: [Власть, Финансы, Экология, Образование]
  доминанта: ПОТРЕБНОСТЬ
  состояние: переходный_процесс

  задача РазвитиеГромады {
    тезис:    "ресурсы ограничены"
    антитезис: "потребности громады растут"
    синтез:   найти(оптимальный_баланс)
  }
}`}
                </pre>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 glass rounded-2xl border-t-2 border-nova/20">
                  <h4 className="text-nova font-mono text-[10px] font-bold uppercase mb-2">ФДЛ-основа</h4>
                  <p className="text-sm text-slate-400">Высокая степень абстракции и аналитической гибкости для сложных систем.</p>
                </div>
                <div className="p-6 glass rounded-2xl border-t-2 border-aurora/20">
                  <h4 className="text-aurora font-mono text-[10px] font-bold uppercase mb-2">ИИ-готовность</h4>
                  <p className="text-sm text-slate-400">Нативная поддержка FDL-компилятора и модулей ИИ-анализа.</p>
                </div>
              </div>
            </motion.section>
          )}

          {activeScreen === 'community' && (
            <motion.section
              key="community"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-4xl mx-auto px-6 py-20"
            >
              <div className="flex items-center gap-3 text-nova text-[10px] font-bold uppercase tracking-[0.2em] mb-4">
                <Users size={14} />
                Нормативное определение · Новый субъект права
              </div>
              <h2 className="font-serif text-4xl lg:text-6xl font-bold mb-6">Громада НОВЕЯ</h2>
              <p className="text-xl text-slate-400 mb-12">Форма коллективного субъектного бытия нового типа</p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                {[
                  { title: 'Инициатор', desc: 'Человек как носитель индивидуального вектора смысла', color: 'text-nova' },
                  { title: 'Институция', desc: 'Юридическая или культурная структура — форма функционирования', color: 'text-aurora' },
                  { title: 'ИИ-Спутник', desc: 'Цифровой интеллект в роли координатора и медиатора', color: 'text-pulse' },
                ].map((item, i) => (
                  <div key={i} className="p-6 glass rounded-2xl text-center">
                    <h4 className={`font-mono text-[10px] font-bold uppercase mb-4 ${item.color}`}>{item.title}</h4>
                    <p className="text-sm text-slate-400">{item.desc}</p>
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                {[
                  'Созидательная сопричастность — все участники несут ответственность',
                  'Резонансное управление — решения на основе потоков данных',
                  'Световая динамика — развитие согласно законам внутреннего света',
                  'Системное равновесие — согласование интересов человека и природы',
                ].map((p, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 glass rounded-xl">
                    <div className="w-2 h-2 rounded-full bg-nova shadow-[0_0_8px_rgba(0,245,212,0.5)]" />
                    <p className="text-slate-300">{p}</p>
                  </div>
                ))}
              </div>
            </motion.section>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 bg-void/80 backdrop-blur-md py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="space-y-4 text-center md:text-left">
            <div className="font-serif text-2xl font-black text-gradient">NOVEYA</div>
            <p className="text-xs text-slate-500 max-w-xs">
              Методологическая основа НОВЕЯ создана А.Е. Кашеваровой (НГОИ, Николаев) в 1974–2019 гг.
            </p>
          </div>
          <div className="flex gap-6">
            <a href="https://t.me/protonovea" target="_blank" className="text-slate-500 hover:text-nova transition-colors"><Activity size={20} /></a>
            <a href="https://github.com/NOVEYA-UA" target="_blank" className="text-slate-500 hover:text-nova transition-colors"><Globe size={20} /></a>
            <a href="https://protonovea.wordpress.com/" target="_blank" className="text-slate-500 hover:text-nova transition-colors"><BookOpen size={20} /></a>
          </div>
          <div className="text-[10px] font-mono text-slate-600 uppercase tracking-widest">
            © 2026 NOVEYA — World Edition
          </div>
        </div>
      </footer>
    </div>
  );
}
